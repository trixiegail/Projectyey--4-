import { default as React } from "react";
import Studfooter from "../components/Studfooter";
import Studnav from "../components/Studnav";

export function Home() {
  const [open, setOpen] = React.useState(1);
 
  const handleOpen = (value) => setOpen(open === value ? 0 : value);
  return (
    <>
      <div>
          <Studnav />
          <img
            className="h-90 w-full items-center"
            src="src/image/Banner.png"
            alt="Your Company"
          />

      <section className="py-16 bg-white">
        <div className="container mx-auto flex flex-col md:flex-row items-center">
          {/* Image Section */}
          <div className="md:w-1/2 w-full px-4 mb-8 md:mb-0">
            <img src="src/image/Aboutus.png" alt="Happy Dental" className="rounded-lg shadow-lg" />
          </div>

          {/* Text Section */}
          <div className="md:w-1/2 w-full px-4">
            <h2 className="text-lg font-semibold text-gray-600 uppercase mb-2">About Us</h2>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Your Trusted Partner For Dental Health</h1>
            <p className="text-gray-700 mb-6">
              Purus turpis vivamus sem est blandit. In at egestas id sollicitudin mattis integer aliquet ut tempor. Risus enim nisi ipsum imperdiet. Sed turpis tellus quisque tellus ipsum malesuada fringilla amet elit.
            </p>
            <div className="flex items-center mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Experienced Dentist</h3>
                <p className="text-gray-600">Purus turpis vivamus sem est blandit in at egestas.</p>
              </div>
            </div>
            <div className="flex items-center">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Affordable Pricing</h3>
                <p className="text-gray-600">Purus turpis vivamus sem est blandit in at egestas.</p>
              </div>
            </div>
          </div>
        </div>

        <video className="h-50 w-50 rounded-lg container mx-auto flex flex-col items-center mt-20" controls autoPlay>
          <source src="https://docs.material-tailwind.com/demo.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </section>

      <section className="py-16 bg-[#88343B] flex pt-20">

      </section>
          <Studfooter />
      </div>


    </>
  );
}

export default Home;
